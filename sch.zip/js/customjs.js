$(document).ready(function a(){
  // alert("HI");
  $("#ajax_catagory").change(function a(){
    var selected = $(this).val();
    $.post(
      "ajax.php",
      {update : selected},
      function(data){
        $("#ajax_product_name").html(data);
      }
    )
  });
});





</script>
<!-- //কাস্টোমার নেইম আনার এজাক্স -->
<script type="text/javascript">

$(document).ready(function b(){
  // alert("HI");
  $("#ajax_customer_email").change(function b(){
    var customer_email = $(this).val();
    $.post(
      "ajax_customer.php",
      {changed_customer_name : customer_email},
      function(data){
        $("#ajax_customer_name").html(data);
      }
    )
  });
});
</script>

// <!-- প্রোডাক্টের প্রাইজ ফেচ -->

<script type="text/javascript">

$(document).ready(function c(){
  // alert("HI");
  $("#ajax_product_name").change(function c(){
    var product_name = $(this).val();
    $.post(
      "ajax_product_name.php",
      {updated_product_name : product_name},
      function(data){
        $("#ajax_product_price").html(data);
      }
    )
  });
});
