

            <ul class="list-group">
              <a href="index.php" class="list-group-item list-group-item-action active">
                <i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard
              </a>

              <li class="list-group-item d-flex justify-content-between align-items-center">
                <a href="products.php"><i class="fa fa-file-text" aria-hidden="true"></i> All Products</a>
              </li>
              <!-- <li class="list-group-item d-flex justify-content-between align-items-center">
                <a href="edit_products.php"><i class="fa fa-file-text" aria-hidden="true"></i> Edit Products</a>
              </li> -->

                <!-- <a href="post_admin.ph"><span class="badge badge-primary badge-pill"></span></a> -->
              <li class="list-group-item d-flex justify-content-between align-items-center">
                <a href="catagory.php"><i class="fa fa-list" aria-hidden="true"></i> Catagories</a>
              </li>

              <li class="list-group-item d-flex justify-content-between align-items-center">
                <a href="sales.php"><i class="fa fa-picture-o" aria-hidden="true"></i> Sales</a>
              </li>

              <li class="list-group-item d-flex justify-content-between align-items-center">
                <a href="customer.php"><i class="fa fa-id-card" aria-hidden="true"></i> Customer Manage</a>
              </li>

              <!-- <li class="list-group-item d-flex justify-content-between align-items-center">
                <a href="registration.php"><i class="fa fa-user" aria-hidden="true"></i> Add Users</a>
              </li>
              <li class="list-group-item d-flex justify-content-between align-items-center">
                <a href="users.php"><i class="fa fa-user" aria-hidden="true"></i> Users</a>
              </li> -->

              <li class="list-group-item d-flex justify-content-between align-items-center">
                <a href="report.php"><i class="fa fa-user" aria-hidden="true"></i> Report</a>
              </li>

            </ul>
