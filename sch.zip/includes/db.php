<?php
$connection = mysqli_connect('localhost','root','','pos');
if (!$connection) {
  echo "we are connected";

}
?>
