<?php include 'includes/header.php'; ?>

<?php include 'includes/nav.php'; ?>
<div class="row">
  <div class="col-md-3">
    <?php include 'includes/sidemanu.php'; ?>
  </div>

  <div class="col-md-9">
    <br>
    <button class="btn btn-secondary"type="button" disabled>Buyers</button>
    <br>
    <hr>
    <div class="row">
      <div class="offset-md-1 col-md-10 offset-1 col-10">


        <table class="table">
          <thead class="thead-dark">
            <tr>
              <th scope="col">Buyer Name</th>
              <th scope="col">Product Name</th>
              <th scope="col">Price</th>
              <th scope="col">Date</th>
              <th scope="col">Renewal Date</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td >Mark</td>
              <td >Laptop</td>
              <td>500$</td>
              <td>12 June 2017</td>
              <td>12 June 2017</td>
            </tr>
            <tr>
              <td >Mark</td>
              <td >Laptop</td>
              <td>500$</td>
              <td>12 June 2017</td>
              <td>12 June 2017</td>
            </tr>
            <tr>
              <td >Mark</td>
              <td >Laptop</td>
              <td>500$</td>
              <td>12 June 2017</td>
              <td>12 June 2017</td>
            </tr>
          </tbody>
        </table>

      </div>


    </div>


  </div>

</div>






































<?php include 'includes/footer.php'; ?>
