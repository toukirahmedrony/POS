<?php
  echo $date = date('Y-m-d', strtotime('+1 month'));
 ?>
